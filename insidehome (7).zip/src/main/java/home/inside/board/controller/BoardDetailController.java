package home.inside.board.controller;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import home.inside.board.service.IBoardDetailService;
import home.inside.board.service.IBoardPostService;
import home.inside.board.vo.BoardVo;
import home.inside.board.vo.PageCommand;
import home.inside.board.vo.SearchCommand;

@Controller
public class BoardDetailController {
	
	@Autowired
	private IBoardDetailService boardDetailService;
	@Autowired
	private IBoardPostService boardPostService;
	
	//게시글 목록, 검색, 페이지
	@RequestMapping("user/board/list.do")
	public String selectAll(SearchCommand searchCmd, Model model, int count) throws Exception{
		Integer pageNum = searchCmd.getPageNum();
		if (pageNum == null) {
			pageNum = 1;
		}
		if (pageNum == 1) {
			count = boardDetailService.count(searchCmd);
		}
		int pageSize = 20;
		int currentPage = pageNum;
		int startNum = (currentPage - 1) * pageSize + 1;
		int endNum = currentPage * pageSize;
		String type = null;
		String str = null;
		List<BoardVo> result = null;
	
		model.addAttribute("result", result);

		int number = count - (currentPage - 1) * pageSize;
		model.addAttribute("number", number);

		PageCommand pageCmd = new PageCommand(currentPage, startNum, endNum, count, pageSize, number);
		model.addAttribute("cmd", pageCmd);

		return "/user/board/list"; 
		
	}
	
	//게시글 상세조회 페이지
	@RequestMapping(value="user/board/read.do", method=RequestMethod.GET)
	public String readBoard(int num, int boardNum, Model model) throws Exception{		
		BoardVo vo = new BoardVo();
		model.addAttribute("board", boardDetailService.readBoard(num));
		model.addAttribute("image", boardDetailService.readimage(boardNum));
		model.addAttribute("ref", boardDetailService.readRef(boardNum));
		
		if(vo.getBoardCode().equals("issue")) {
			model.addAttribute("term", boardPostService.selectTerm(boardNum));
		}
        return "/user/board/infoRead";
		
	}
	
	//게시글 추천 요청
	@RequestMapping(value="user/board/hit.do", method=RequestMethod.GET)
	public String updateHeart(int num) throws Exception{
		boardDetailService.updateHeart(num);
		return "forward:/user/board/";
	}
	
	

}
