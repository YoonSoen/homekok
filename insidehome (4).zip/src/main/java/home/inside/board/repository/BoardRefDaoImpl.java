package home.inside.board.repository;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import home.inside.board.vo.BoardRefVo;

@Repository
public class BoardRefDaoImpl implements IBoardRefDao {
	
	@Autowired
	private SqlSessionTemplate sqlSessionTemplate;

	@Override
	public void insert(BoardRefVo refVo) throws Exception {
		sqlSessionTemplate.insert("boardrefInsert", refVo);

	}

	@Override
	public void update(BoardRefVo refVo) throws Exception {
		sqlSessionTemplate.update("boardrefUpdate", refVo);

	}

	@Override
	public void delete(int num) throws Exception {
		sqlSessionTemplate.delete("boardrefDelete", num);

	}

	@Override
	public void deleteAll(int boardNum) throws Exception {
		sqlSessionTemplate.delete("boardrefDeleteAll", boardNum);

	}

	@Override
	public List<BoardRefVo> selectAll(int boardNum) throws Exception {
		return sqlSessionTemplate.selectList("boardrefSelectAll", boardNum);
	}

}
