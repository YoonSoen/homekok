package home.inside.board.repository;

import java.util.HashMap;
import java.util.List;

import home.inside.board.vo.BoardImageVo;
import home.inside.board.vo.BoardVo;

public interface IBoardImageDao {
	//이미지 등록
	public void insert(BoardImageVo imageVo) throws Exception;
	//이미지 삭제
	public void delete(HashMap<String, String> hm) throws Exception;
	//이미지 일괄 삭제
	public void deleteAll(int boardNum) throws Exception;
	//이미지 목록 조회
	public List<BoardImageVo> selectAll(int boardNum) throws Exception;

}
