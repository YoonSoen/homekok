package home.inside.board.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import home.inside.board.service.IBoardDetailService;
import home.inside.board.service.IBoardPostService;
import home.inside.board.vo.BoardTermVo;
import home.inside.board.vo.BoardVo;
import home.inside.common.service.IPointService;

@Controller
public class BoardPostController {
	
	@Autowired
	private IBoardDetailService boardDetailService;
	@Autowired
	private IBoardPostService boardPostService;
	@Autowired
	private IPointService pointService;
	
	//글 작성 페이지
	public String insertBoardForm(HttpSession session) throws Exception{
		return null;
	}
	
	//글 작성 요청
	public String insertBoardSubmit(BoardVo vo, BoardTermVo termVo, MultipartHttpServletRequest mpReq) throws Exception{
		return null;
	}
	
	//글 수정 페이지
	public String updateBoardForm(int num, Model model) throws Exception{
		return null;
	}
	
	//글 수정 요청
	public String updateBoardSubmit(BoardVo vo, BoardTermVo termVo, MultipartHttpServletRequest mpReq) throws Exception{
		return null;
	}
	
	//글 삭제 요청
	public String deleteBoardSubmit(int num) throws Exception{
		return null;
	}

}
