package home.inside.supporter.controller;

import javax.servlet.http.HttpSession;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.Mapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.request.ServletRequestAttributes;

import home.inside.common.service.IPointService;
import home.inside.member.service.IMemberInfoService;
import home.inside.supporter.service.IWarningService;
import home.inside.supporter.vo.WarningVo;

@Controller
public class WarningController {

	@Autowired
	IWarningService service;
	@Autowired
	IPointService pointService;
	@Autowired
	IMemberInfoService imemberInfoService;

	// 신고 접수작성
	@RequestMapping(value = "/user/warning/insert.do", method = RequestMethod.POST)
	public String insertwarningForm(Integer boardNum) throws Exception {
		if(boardNum==null || boardNum<1) {
			return "redirect:/inside/main.do";
		}
		return "user/supporter/warning";
	}

	// 신고 접수요청
	@RequestMapping(value = "/user/warning/insert.do", method = RequestMethod.POST)
	public String insertwariningSubmit(WarningVo vo, HttpSession session) throws Exception {
		service.insertWarning(vo);
		String nickname = vo.getNickname();
		int warnCount = service.selectCount(nickname);
		if (warnCount == 3) {
			pointService.insertPoint(nickname, "warning", -1000);
		} else if (warnCount == 5) {
			return "forward:/user/mypage/info/drop.do";
		}
		return "redirect:/inside/main.do";

	}
}
