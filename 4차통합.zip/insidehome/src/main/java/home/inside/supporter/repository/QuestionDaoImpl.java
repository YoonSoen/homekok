package home.inside.supporter.repository;

import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import home.inside.supporter.vo.QuestionCommand;
import home.inside.supporter.vo.QuestionVo;

@Repository
public class QuestionDaoImpl implements IQuestionDao {
	
	@Autowired
	private SqlSessionTemplate sqlSessionTemplate;

	//qa 및 고객문의 등록
	@Override
	public void insert(QuestionVo vo) throws Exception {
		sqlSessionTemplate.insert("questioninsert", vo);
	}

	//수정(고객문의 답변, qa수정)
	@Override
	public void update(QuestionVo vo) throws Exception {
		sqlSessionTemplate.update("questionupdate", vo);
	}
	//목록조회
	@Override
	public List<QuestionVo> selectAll(HashMap<String, Object> hm) throws Exception {
		return sqlSessionTemplate.selectList("questionselectall", hm);
	}
	//내용확인
	@Override
	public QuestionVo selectOne(int num) throws Exception {
		return sqlSessionTemplate.selectOne("questionselectone", num);
	}
	//회원탈퇴
	@Override
	public void deleteQuestion(String nickname) throws Exception {
		sqlSessionTemplate.delete("questiondeletequestion", nickname);
	}
}
