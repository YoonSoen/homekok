package home.inside.supporter.service;

import org.springframework.stereotype.Service;

import home.inside.supporter.vo.WarningVo;

@Service
public interface IWarningService {
	// 신고접수
	public void insertWarning(WarningVo vo) throws Exception;
	// 신고횟수 조회
	public int selectCount(String nickname) throws Exception;
	// 신고삭제
	public void deleteWarning(String nickname) throws Exception;
}
