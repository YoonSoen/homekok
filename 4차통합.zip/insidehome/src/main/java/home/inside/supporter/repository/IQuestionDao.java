package home.inside.supporter.repository;

import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;

import home.inside.supporter.vo.QuestionCommand;
import home.inside.supporter.vo.QuestionVo;

@Repository
public interface IQuestionDao {
	// QA(관리자) 및 고객문의(사용자) 등록
	public void insert(QuestionVo vo) throws Exception;
	
	//QA 수정 및 고객문의 답변등록
	public void update(QuestionVo vo) throws Exception;
	
	//QA 고객문의 목록확인
	public List<QuestionVo> selectAll(HashMap<String, Object> hm) throws Exception;
	
	// 고객문의 상세내용확인
	public QuestionVo selectOne(int num) throws Exception;
	
	// 회원탈퇴/제적 시 문의내용 삭제
	public void deleteQuestion(String nickname) throws Exception;

}
