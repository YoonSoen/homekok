package home.inside.board.repository;

import java.util.List;

import home.inside.board.vo.BoardRefVo;

public interface IBoardRefDao {
	// 댓글 작성
	public void insert(BoardRefVo refVo) throws Exception;

	// 댓글 수정
	public void update(BoardRefVo refVo) throws Exception;

	// 댓글 삭제(num:댓글번호)
	public void delete(int num) throws Exception;

	// 댓글 일괄 삭제(게시글 삭제,회원탈퇴 시 필요)
	public void deleteAll(int boardNum) throws Exception;

	// 댓글 전체조회
	public List<BoardRefVo> selectAll(int boardNum) throws Exception;

}
