package home.inside.board.repository;

import java.util.HashMap;
import java.util.List;

import home.inside.board.vo.BoardVo;

public interface IBoardDao {
	// 글 작성
	public void insert(BoardVo vo) throws Exception;

	// 글 수정
	public void update(BoardVo vo) throws Exception;

	// 글 삭제
	public void delete(int num) throws Exception;

	// 특정 회원 게시글 일괄 삭제
	public void deleteAll(String nickname) throws Exception;

	// 글 상세조회
	public BoardVo selectOne(int num) throws Exception;

	// 글 목록조회
	public List<BoardVo> selectAll(HashMap<String, Object> hm) throws Exception;

	// 글 목록 검색
	public List<BoardVo> searchAll(HashMap<String, Object> hm) throws Exception;

	// 조회수 증가
	public void updateHit(int num) throws Exception;

	// 추천수 증가
	public void updateHeart(int num) throws Exception;

	// 마이페이지 내 글 조회
	public List<BoardVo> searchNickname(String nickname) throws Exception;

}
