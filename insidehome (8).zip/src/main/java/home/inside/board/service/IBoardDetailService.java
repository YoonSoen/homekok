package home.inside.board.service;

import java.util.List;

import home.inside.board.vo.BoardImageVo;
import home.inside.board.vo.BoardRefVo;
import home.inside.board.vo.BoardVo;
import home.inside.board.vo.SearchCommand;

public interface IBoardDetailService {
	// 게시글 목록, 검색, 페이징
	public List<BoardVo> selectAll(SearchCommand searchCmd, int startNum, int endNum) throws Exception;

	// 게시글 내용 상세조회 + 조회수 증가
	public BoardVo readBoard(int num) throws Exception;

	// 이미지목록 조회
	public List<BoardImageVo> readimage(int boardNum) throws Exception;

	// 댓글 목록 조회
	public List<BoardRefVo> readRef(int boardNum) throws Exception;

	// 게시글 추천
	public void updateHeart(int num) throws Exception;

	// 댓글 등록
	public void insertRef(BoardRefVo refVo) throws Exception;

	// 댓글 수정
	public void updateRef(BoardRefVo refVo) throws Exception;

	// 댓글 삭제
	public void deleteRef(int num) throws Exception;

	// 마이페이지
	public List<BoardVo> searchNickname(String nickname) throws Exception;

}
