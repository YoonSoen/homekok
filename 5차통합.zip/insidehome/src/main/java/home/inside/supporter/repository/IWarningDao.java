package home.inside.supporter.repository;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Repository;

import home.inside.supporter.vo.WarningVo;

@Repository
public interface IWarningDao {
	// 신고접수
	public void insert(WarningVo vo) throws Exception;
	
	//신고횟수 확인
	public int selectCount(String nickname) throws Exception;
	
	// 탈퇴시 내용삭제
	public void delete(String nickname) throws Exception;
}
