package home.inside.supporter.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import home.inside.supporter.service.IQuestionService;
import home.inside.supporter.vo.QuestionVo;
/*
 * @Controller public class QuestionController {
 * 
 * @Autowired IQuestionService service;
 * 
 * // 문의등록 폼 요청
 * 
 * @RequestMapping(value = "/user/question/insert.do") public String
 * insertQuestionForm() throws Exception { return
 * "user/supporter/insertQuestion"; }
 * 
 * // 문의 등록 처리 public String insertQuestionSubmit(QuestionVo vo, HttpSession
 * session) throws Exception{ String nickname = (String)
 * session.getAttribute("loginInside");
 * 
 * vo.setAskType("customer"); vo.setNickname(nickname); String title =
 * vo.getTitle(); String content = vo.getContent(); if(title==null ||
 * title.trim().isEmpty() || content==null || content.trim().isEmpty()) { return
 * "user/supporter/insertQuestion"; }else { service.insert(vo); return
 * "redirect:/user/question/list.do"; } } // qa 목록 확인
 * 
 * @RequestMapping(value = "/question/list.do") public String SelectQA(String
 * type, Model model) throws Exception { model.addAttribute("list",
 * service.selectAll(type, null)); return "user/supporter/qaList";
 * 
 * }
 * 
 * // question목록확인
 * 
 * @RequestMapping(value = "/user/question/list.do") public String
 * SelectQuestion(String type, Model model, HttpSession session) throws
 * Exception { String nickname = (String) session.getAttribute("loginInside");
 * 회원이 고객문의페이지(내꺼)를 요청할 경우, asktype 에 customer 를넣어서 넘겨준다.(hidden) if
 * (type.equals("customer")) { model.addAttribute("list",
 * service.selectAll(type, nickname)); } return "user/supporter/questionList"; }
 * 
 * // 내용확인
 * 
 * @RequestMapping(value = "/user/question/detail.do", method =
 * RequestMethod.POST) public String SelectOne(int num, Model model) throws
 * Exception { QuestionVo vo = service.selectOne(num);
 * model.addAttribute("detail", vo); return "user/supporter/questionList"; }
 * 
 * }
 */