package home.inside.board.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import home.inside.board.service.IBoardDetailService;
import home.inside.board.service.IBoardPostService;
import home.inside.board.vo.BoardVo;
import home.inside.board.vo.SearchCommand;

@Controller
public class BoardDetailController {
	
	@Autowired
	private IBoardDetailService boardDetailService;
	@Autowired
	private IBoardPostService boardPostService;
	
	//게시글 목록, 검색, 페이지
	@RequestMapping("user/board/list.do")
	public String selectAll(SearchCommand searchCmd, Model model) throws Exception{
		String boardCode = "";
		int startNum = 0;
		int endNum = 0;
		
		List<BoardVo> list = boardDetailService.selectAll(searchCmd, startNum, endNum);
		model.addAttribute("list", list);
		return "/user/board/list"; 
		
	}
	
	//게시글 상세조회 페이지
	@RequestMapping(value="user/board/read.do", method=RequestMethod.GET)
	public String readBoard(int num, Model model) throws Exception{		
		BoardVo data = boardDetailService.readBoard(num);
        model.addAttribute("data", data);
        return "/user/board/infoRead";
		
	}
	
	//게시글 추천 요청
	@RequestMapping(value="user/board/hit.do", method=RequestMethod.GET)
	public String updateHeart(int num) throws Exception{
		boardDetailService.updateHeart(num);
		return null;
	}
	
	

}
