package home.inside.board.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import home.inside.board.service.IBoardDetailService;
import home.inside.board.service.IBoardPostService;
import home.inside.board.vo.BoardRefVo;

@Controller
public class BoardRefController {
	
	@Autowired
	private IBoardDetailService boardDetailService;
	@Autowired
	private IBoardPostService boardPostService;
	
	//댓글 등록 요청
	@RequestMapping(value = "user/board/inref.do" , method = RequestMethod.POST)
	public String insertRefSubmit(BoardRefVo refVo) throws Exception{
		boardDetailService.insertRef(refVo);
		
		return "redirect:/user/board";
	}
	
	//댓글 수정 요청
	@RequestMapping(value = "user/board/upref.do" , method = RequestMethod.POST)
	public String updateRefSubmit(BoardRefVo refVo, Model model) throws Exception{
		boardDetailService.updateRef(refVo);		
		model.addAttribute("content", refVo.getContent());
		return "redirect:/user/board";
	}
	
	//댓글 삭제 요청
	@RequestMapping(value = "user/board/deref.do" , method = RequestMethod.POST)
	public String deleteRefSubmit(int num) throws Exception{
		boardDetailService.deleteRef(num);
		return "redirect:/user/board";
	}
	

}
 