package home.inside.board.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import home.inside.board.service.IBoardDetailService;
import home.inside.board.service.IBoardPostService;

@Controller
public class BoardTermController {
	
	@Autowired
	private IBoardDetailService boardDetailService;
	@Autowired
	private IBoardPostService boardPostService;
	
	//이슈게시판 목록, 감색페이지
	public String searchAll(String boardCode, Date startDate, Date endDate, Model model) throws Exception{
		return null;
	}
}
