package home.inside.board.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import home.inside.board.repository.IBoardDao;
import home.inside.board.repository.IBoardImageDao;
import home.inside.board.repository.IBoardRefDao;
import home.inside.board.repository.IBoardTermDao;
import home.inside.board.vo.BoardImageVo;
import home.inside.board.vo.BoardRefVo;
import home.inside.board.vo.BoardVo;
import home.inside.board.vo.SearchCommand;

@Service
public class BoardDetailServiceImpl implements IBoardDetailService {
	
	@Autowired
	private IBoardDao dao;
	@Autowired
	private IBoardImageDao imageDao;
	@Autowired
	private IBoardRefDao refDao;
	
	

	@Override
	public List<BoardVo> selectAll(String boardCode, int startNum, int endNum) throws Exception {
		HashMap<String, Object> hm = new HashMap<>();
		hm.put("boardCode", boardCode);
		hm.put("startNum", startNum);
		hm.put("endNum", endNum);
		return dao.selectAll(hm); // 페이징처리
	}

	@Override
	public List<BoardVo> searchAll(SearchCommand searchCmd, int startNum, int endNum) throws Exception {
		HashMap<String, Object> hm = new HashMap<>();
		hm.put("searchCmd", searchCmd);
		hm.put("startNum", startNum);
		hm.put("endNum", endNum);
		return dao.searchAll(hm); //검색후 검색된 결과 페이징
	}

	@Override
	public BoardVo readBoard(int num) throws Exception {
		return dao.selectOne(num);
	}

	@Override
	public List<BoardImageVo> readmage(int boardNum) throws Exception {
		return imageDao.selectAll(boardNum);
	}

	@Override
	public List<BoardRefVo> readRef(int boardNum) throws Exception {
		return refDao.selectAll(boardNum);
	}

	@Override
	public void updateHeart(int num) throws Exception {
		dao.updateHeart(num);
	}

	@Override
	public void insertRef(BoardRefVo refVo) throws Exception {
		refDao.insert(refVo);
	}

	@Override
	public void updateRef(BoardRefVo refVo) throws Exception {
		refDao.update(refVo);
	}

	@Override
	public void deleteRef(int num) throws Exception {
		refDao.delete(num);
	}

	@Override
	public List<BoardVo> searchNickname(String nickname) throws Exception {
		return dao.searchNickname(nickname);
	}

}
