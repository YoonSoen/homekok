package home.inside.board.repository;

import java.util.HashMap;
import java.util.List;

import home.inside.board.vo.BoardTermVo;

public interface IBoardTermDao {
	//기간 등록
	public void insert(BoardTermVo termVo) throws Exception;
	//기간 수정
	public void update(BoardTermVo termVo) throws Exception;
	//기간 삭제(게시글삭제 시 필요)
	public void delete(int boardNum) throws Exception;
	//기간 조회
	public BoardTermVo selectOne(int num) throws Exception;
	//기간 검색
	public List<Integer> searchAll(HashMap<String, String> hm) throws Exception;

}
