package home.inside.supporter.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import home.inside.supporter.repository.IWarningDao;
import home.inside.supporter.vo.WarningVo;

@Service
public class WarningServiceImpl implements IWarningService{
	@Autowired
	IWarningDao dao;	
	
	public void insertWarning(WarningVo vo) throws Exception {
		dao.insert(vo);
	}
	public int selectCount(String nickname) throws Exception {
		return dao.selectCount(nickname);
	}
	public void deleteWarning(String nickname) throws Exception {
		dao.delete(nickname);
	}
	
	
}
