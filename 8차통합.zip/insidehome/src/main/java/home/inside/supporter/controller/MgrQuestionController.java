package home.inside.supporter.controller;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.ModelAndView;

import home.inside.supporter.service.IQuestionService;
import home.inside.supporter.vo.QuestionVo;
/*
 * @Controller public class MgrQuestionController {
 * 
 * @Autowired(required = true) IQuestionService service;
 * 
 * // q&a등록
 * 
 * @RequestMapping(value = "/manager/question/insert.do", method =
 * RequestMethod.GET) public String insertQuestionForm() throws Exception {
 * return ""; }
 * 
 * // q&a등록요청
 * 
 * @RequestMapping(value = "/manager/question/insert.do", method =
 * RequestMethod.POST) public String insertQuestionSubmit(QuestionVo vo) throws
 * Exception { service.insert(vo); return "qa목록"; }
 * 
 * // 고객문의 수정(고객문의 답변등록, q&a 수정)
 * 
 * @RequestMapping(value = "/manager/question/update.do", method =
 * RequestMethod.GET) public String updateQuestionForm(int num, Model model)
 * throws Exception { QuestionVo vo = new QuestionVo(); service.update(vo);
 * HttpServletRequest request = ((ServletRequestAttributes)
 * RequestContextHolder.currentRequestAttributes()) .getRequest();
 * 
 * HttpSession session = request.getSession(); String sessionid = (String)
 * session.getAttribute("sessionid");
 * 
 * if (vo.getNickname() == sessionid) { // 세션아이디(관리자)와 작성닉네임이 다르면 작성자가 회원이라는 거니까
 * updatequestion으로 이동 return "업데이트폼"; } else { return "답변등록폼"; } }
 * 
 * // 고객문의 수정(고객문의 답변등록, q&a 수정) 요청
 * 
 * @RequestMapping(value = "/manager/question/update.do", method =
 * RequestMethod.POST) public String updateQuestionSubmit(QuestionVo vo) throws
 * Exception { service.update(vo);
 * 
 * return "목록"; }
 * 
 * // 목록조회(관리자 고객문의 목록, q&a목록)
 * 
 * @RequestMapping(value = "/manager/question/list.do", method =
 * RequestMethod.POST) public String SelectAll(String asktype, String nickname,
 * Model model) throws Exception {
 * 
 * 고객문의목록일 경우
 * 
 * 
 * 
 * HttpServletRequest request = ((ServletRequestAttributes)
 * RequestContextHolder.currentRequestAttributes()) .getRequest(); HttpSession
 * session = request.getSession(); QuestionVo vo = new QuestionVo();
 * 
 * String sessionid = (String) session.getAttribute("sessionid");
 * List<QuestionVo> list = service.selectAll(asktype, nickname);
 * model.addAttribute("list", list);
 * 
 * if (asktype.equals("customer")) { // 세션아이디(관리자)와 작성닉네임이 다르면 작성자가 회원이라는 거니까
 * questionlist으로 이동 return "고객문의목록"; } else { return "qa목록"; } }
 * 
 * // 내용확인
 * 
 * @RequestMapping(value = "/manager/question/detail.do", method =
 * RequestMethod.POST) public String SelectOne(int num, Model model) throws
 * Exception { QuestionVo vo = new QuestionVo();
 * 
 * QuestionVo det = service.selectOne(num); model.addAttribute("det", det);
 * 
 * return "고객문의 상세조회";
 * 
 * }
 * 
 * }
 */