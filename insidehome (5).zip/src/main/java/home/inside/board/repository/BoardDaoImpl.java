package home.inside.board.repository;

import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import home.inside.board.vo.BoardVo;

@Repository
public class BoardDaoImpl implements IBoardDao{
	@Autowired
	private SqlSessionTemplate sqlSessionTemplate;

	@Override
	public void insert(BoardVo vo) throws Exception {
		sqlSessionTemplate.insert("boardInsert", vo);
	}

	@Override
	public void update(BoardVo vo) throws Exception {
		sqlSessionTemplate.update("boardUpdate", vo);
	}

	@Override
	public void delete(int num) throws Exception {
		sqlSessionTemplate.delete("boardDelete", num);
	}

	@Override
	public void deleteAll(String nickname) throws Exception {
		sqlSessionTemplate.delete("boardDeleteAll", nickname);
	}

	@Override
	public BoardVo selectOne(int num) throws Exception {
		return sqlSessionTemplate.selectOne("boardselectOne", num);
	}

	@Override
	public List<BoardVo> selectAll(HashMap<String, Object> hm) throws Exception {
		return sqlSessionTemplate.selectList("boardselectAll", hm);
	}

	@Override
	public List<BoardVo> searchAll(HashMap<String, Object> hm) throws Exception {
		return sqlSessionTemplate.selectList("boardsearchAll", hm);
	}

	@Override
	public void updateHit(int num) throws Exception {
		sqlSessionTemplate.update("boardupdateHit", num);
	}

	@Override
	public void updateHeart(int num) throws Exception {
		sqlSessionTemplate.update("boardupdateHeart", num);
	}

	@Override
	public List<BoardVo> searchNickname(HashMap<String, Object> hm) throws Exception {
		return sqlSessionTemplate.selectList("boardsearchNickname", hm);
	}

	@Override
	public int count(HashMap<String, Object> hm) throws Exception {
		return sqlSessionTemplate.selectOne("boardCount", hm);
	}

}
