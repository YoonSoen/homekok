package home.inside.board.repository;

import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import home.inside.board.vo.BoardImageVo;
import home.inside.board.vo.BoardVo;

@Repository
public class BoardImageDaoImpl implements IBoardImageDao {
	
	@Autowired
	private SqlSessionTemplate sqlSessionTemplate;

	@Override
	public void insert(BoardImageVo imageVo) throws Exception {
		sqlSessionTemplate.insert("boardimageInsert", imageVo);
	}

	@Override
	public void delete(HashMap<String, String> hm) throws Exception {
		sqlSessionTemplate.delete("boardimageDelete", hm);
	}

	@Override
	public void deleteAll(int boardNum) throws Exception {
		sqlSessionTemplate.delete("boardimageDeleteAll", boardNum);
	}

	@Override
	public List<BoardImageVo> selectAll(int boardNum) throws Exception {
		return sqlSessionTemplate.selectList("boardimageSelectAll", boardNum);
	}

}
