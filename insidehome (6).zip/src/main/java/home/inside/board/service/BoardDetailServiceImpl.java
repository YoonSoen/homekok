package home.inside.board.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.crypto.dsig.spec.HMACParameterSpec;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import home.inside.board.repository.IBoardDao;
import home.inside.board.repository.IBoardImageDao;
import home.inside.board.repository.IBoardRefDao;
import home.inside.board.repository.IBoardTermDao;
import home.inside.board.vo.BoardImageVo;
import home.inside.board.vo.BoardRefVo;
import home.inside.board.vo.BoardVo;
import home.inside.board.vo.SearchCommand;

@Service
public class BoardDetailServiceImpl implements IBoardDetailService {
	
	@Autowired
	private IBoardDao dao;
	@Autowired
	private IBoardImageDao imageDao;
	@Autowired
	private IBoardRefDao refDao;
	
	

	@Override
	public List<BoardVo> selectAll(SearchCommand searchCmd, int startNum, int endNum) throws Exception {	
		HashMap<String, Object> hm = new HashMap<>();
		hm.put("boardCode", searchCmd.getBoardCode());
		hm.put("startNum", startNum);
		hm.put("endNum", endNum);
		
		if(searchCmd.getSearchWord() == null || searchCmd.getSearchWord().trim().isEmpty()){
			   return dao.selectAll(hm);
			   
			} else {
			   if(searchCmd.getSearchType().equals("double")){ //제목또는 내용검색일 경우
			      hm.put("type", "title");
			      hm.put("type2", "content");
			   } else {
			      hm.put("type", searchCmd.getSearchType());
			   }
			   hm.put("word", searchCmd.getSearchWord());
			   return dao.searchAll(hm);
			}
	}


	@Override
	public BoardVo readBoard(int num) throws Exception {
		return dao.selectOne(num);
	}

	@Override
	public List<BoardImageVo> readimage(int boardNum) throws Exception {
		return imageDao.selectAll(boardNum);
	}

	@Override
	public List<BoardRefVo> readRef(int boardNum) throws Exception {
		return refDao.selectAll(boardNum);
	}

	@Override
	public void updateHeart(int num) throws Exception {
		dao.updateHeart(num);
	}

	@Override
	public void insertRef(BoardRefVo refVo) throws Exception {
		refDao.insert(refVo);
	}

	@Override
	public void updateRef(BoardRefVo refVo) throws Exception {
		refDao.update(refVo);
	}

	@Override
	public void deleteRef(int num) throws Exception {
		refDao.delete(num);
	}

	@Override
	public List<BoardVo> searchNickname(String nickname, String str) throws Exception {
		HashMap<String, Object> hm = new HashMap<String, Object>();
		hm.put("writer", nickname);
		hm.put("str", str);
		return dao.searchNickname(hm);
	}


	@Override
	public int count(SearchCommand searchCmd) throws Exception {
		HashMap<String, Object> hm = new HashMap<String, Object>();
		if(searchCmd.getSearchWord() == null || searchCmd.getSearchWord().trim().isEmpty()){
			hm.put("boardCode", searchCmd.getBoardCode());
			return dao.count(hm);
			} else {
			   if(searchCmd.getSearchType().equals("double")){ //제목또는 내용검색일 경우
			      hm.put("type", "title");
			      hm.put("type2", "content");
			   } else {
			      hm.put("type", searchCmd.getSearchType());
			   }
			   hm.put("word", searchCmd.getSearchWord());
			   return dao.count(hm);
			}
	}

}
