package home.inside.board.vo;

public class PageCommand {
	private String boardCode;
	private int currentPage;
	private int boardStartNum;
	private int startNum;
	private int endNum;
	private int boardCount;
	private int pageSize;
	
	
	
	public PageCommand(int currentPage2, int start, int end, Integer count, int pageSize2, int number) {
	}
	
		
	public String getBoardCode() {
		return boardCode;
	}
	public void setBoardCode(String boardCode) {
		this.boardCode = boardCode;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public int getBoardStartNum() {
		return boardStartNum;
	}
	public void setBoardStartNum(int boardStartNum) {
		this.boardStartNum = boardStartNum;
	}
	public int getStartNum() {
		return startNum;
	}
	public void setStartNum(int startNum) {
		this.startNum = startNum;
	}
	public int getEndNum() {
		return endNum;
	}
	public void setEndNum(int endNum) {
		this.endNum = endNum;
	}
	public int getBoardCount() {
		return boardCount;
	}
	public void setBoardCount(int boardCount) {
		this.boardCount = boardCount;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	
	

}
