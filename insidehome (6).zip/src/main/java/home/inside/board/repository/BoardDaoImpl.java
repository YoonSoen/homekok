package home.inside.board.repository;

import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import home.inside.board.vo.BoardVo;

@Repository
public class BoardDaoImpl implements IBoardDao{
	
	@Autowired
	private SqlSessionTemplate sqlSessionTemplate;

	@Override
	public void insert(BoardVo vo) throws Exception {
		sqlSessionTemplate.insert("board.boardInsert", vo);
	}

	@Override
	public void update(BoardVo vo) throws Exception {
		sqlSessionTemplate.update("board.boardUpdate", vo);
	}

	@Override
	public void delete(int num) throws Exception {
		sqlSessionTemplate.delete("board.boardDelete", num);
	}

	@Override
	public void deleteAll(String nickname) throws Exception {
		sqlSessionTemplate.delete("board.boardDeleteAll", nickname);
	}

	@Override
	public BoardVo selectOne(int num) throws Exception {
		return sqlSessionTemplate.selectOne("board.boardselectOne", num);
	}

	@Override
	public List<BoardVo> selectAll(HashMap<String, Object> hm) throws Exception {
		return sqlSessionTemplate.selectList("board.boardselectAll", hm);
	}

	@Override
	public List<BoardVo> searchAll(HashMap<String, Object> hm) throws Exception {
		return sqlSessionTemplate.selectList("board.boardsearchAll", hm);
	}

	@Override
	public void updateHit(int num) throws Exception {
		sqlSessionTemplate.update("board.boardupdateHit", num);
	}

	@Override
	public void updateHeart(int num) throws Exception {
		sqlSessionTemplate.update("board.boardupdateHeart", num);
	}

	@Override
	public List<BoardVo> searchNickname(HashMap<String, Object> hm) throws Exception {
		return sqlSessionTemplate.selectList("board.boardsearchNickname", hm);
	}

	@Override
	public int count(HashMap<String, Object> hm) throws Exception {
		return sqlSessionTemplate.selectOne("board.boardCount", hm);
	}

}
