package home.inside.board.repository;

import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import home.inside.board.vo.BoardTermVo;

@Repository
public class BoardTermDaoImpl implements IBoardTermDao {
	
	@Autowired
	private SqlSessionTemplate sqlSessionTemplate;

	@Override
	public void insert(BoardTermVo termVo) throws Exception {
		sqlSessionTemplate.insert("boardterm.boardtermInsert", termVo);
	}

	@Override
	public void update(BoardTermVo termVo) throws Exception {
		sqlSessionTemplate.update("boardterm.boardtermUpdate", termVo);
	}

	@Override
	public void delete(int boardNum) throws Exception {
		sqlSessionTemplate.delete("boardterm.boardtermDelete", boardNum);
	}

	@Override
	public BoardTermVo selectOne(int num) throws Exception {
		return sqlSessionTemplate.selectOne("boardterm.boardtermSelectOne", num);
	}

	@Override
	public List<Integer> searchAll(HashMap<String, String> hm) throws Exception {
		return sqlSessionTemplate.selectList("boardterm.boardtermSearchAll", hm);
	}

}
