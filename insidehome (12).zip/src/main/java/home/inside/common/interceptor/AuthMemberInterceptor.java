package home.inside.common.interceptor;

public class AuthMemberInterceptor {

}
