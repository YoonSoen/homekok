package home.inside.board.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import home.inside.board.repository.IBoardDao;
import home.inside.board.repository.IBoardImageDao;
import home.inside.board.repository.IBoardRefDao;
import home.inside.board.repository.IBoardTermDao;
import home.inside.board.vo.BoardTermVo;
import home.inside.board.vo.BoardVo;

@Service
public class IBoardPostServiceImpl implements IBoardPostService {
	
	@Autowired
	private IBoardDao dao;
	@Autowired
	private IBoardImageDao imageDao;
	@Autowired
	private IBoardRefDao refDao;
	@Autowired
	private IBoardTermDao termDao;
	

	@Override
	public void insertBoard(BoardVo vo, MultipartHttpServletRequest mpRep) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateBoard(BoardVo vo, MultipartHttpServletRequest mpRep) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteBoard(int boardNum) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteAllBoard(String nickname, int boardNum) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void insertTerm(BoardTermVo termVo) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateTerm(BoardTermVo termVo) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteTerm(int boardNum) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public BoardTermVo selectTerm(int num) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Integer> searchAll(Date startDate, Date endDate) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
