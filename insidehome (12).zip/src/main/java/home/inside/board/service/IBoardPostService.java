package home.inside.board.service;

import java.util.Date;
import java.util.List;

import org.springframework.web.multipart.MultipartHttpServletRequest;

import home.inside.board.vo.BoardTermVo;
import home.inside.board.vo.BoardVo;

public interface IBoardPostService {
	//게시글 등록+이미지 등록
	public void insertBoard(BoardVo vo, MultipartHttpServletRequest mpRep) throws Exception;
	
	//게시글 수정+이미지 등록
	public void updateBoard(BoardVo vo, MultipartHttpServletRequest mpRep) throws Exception;
	
	//게시글 삭제+이미지, 댓글
	public void deleteBoard(int boardNum) throws Exception;
	
	//회원 탈퇴 시 게시글 일괄 삭제
	public void deleteAllBoard(String nickname, int boardNum) throws Exception;
	
	//기간 등록
	public void insertTerm(BoardTermVo termVo) throws Exception;
	
	//기간 수정
	public void updateTerm(BoardTermVo termVo) throws Exception;

	//기간 삭제
	public void deleteTerm(int boardNum) throws Exception;
	
	//기간 조회
	public BoardTermVo selectTerm(int num) throws Exception;
	
	//기간 검색
	public List<Integer> searchAll(Date startDate, Date endDate) throws Exception;

}
