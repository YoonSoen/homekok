package home.inside.board.vo;

public class SearchCommand {
	private String boardCode;
	private int pageNum;
	private String searchWorld;
	private String searchType;
	
	public String getBoardCode() {
		return boardCode;
	}
	public void setBoardCode(String boardCode) {
		this.boardCode = boardCode;
	}
	public int getPageNum() {
		return pageNum;
	}
	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
	}
	public String getSearchWorld() {
		return searchWorld;
	}
	public void setSearchWorld(String searchWorld) {
		this.searchWorld = searchWorld;
	}
	public String getSearchType() {
		return searchType;
	}
	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}
	
	
	

}
