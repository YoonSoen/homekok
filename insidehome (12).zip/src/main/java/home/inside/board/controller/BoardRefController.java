package home.inside.board.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import home.inside.board.service.IBoardDetailService;
import home.inside.board.service.IBoardPostService;
import home.inside.board.vo.BoardRefVo;

@Controller
public class BoardRefController {
	
	@Autowired
	private IBoardDetailService boardDetailService;
	@Autowired
	private IBoardPostService boardPostService;
	
	//댓글 등록 요정
	public String insertRefSubmit(BoardRefVo refVo) throws Exception{
		boardDetailService.insertRef(refVo);
		return null;
	}
	
	//댓글 수정 요청
	public String updateRefSubmit(BoardRefVo refVo, Model model) throws Exception{
		return null;
	}
	
	//댓글 삭제 요청
	public String deleteRefSubmit(int num) throws Exception{
		boardDetailService.deleteRef(num);
		return null;
	}

}
