package home.inside.board.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import home.inside.board.repository.IBoardDao;
import home.inside.board.repository.IBoardImageDao;
import home.inside.board.repository.IBoardRefDao;
import home.inside.board.repository.IBoardTermDao;
import home.inside.board.vo.BoardImageVo;
import home.inside.board.vo.BoardRefVo;
import home.inside.board.vo.BoardVo;
import home.inside.board.vo.SearchCommand;

@Service
public class BoardDetailServiceImpl implements IBoardDetailService {
	
	@Autowired
	private IBoardDao dao;
	@Autowired
	private IBoardImageDao imageDao;
	@Autowired
	private IBoardRefDao refDao;
	@Autowired
	private IBoardTermDao termDao;
	

	@Override
	public List<BoardVo> selectAll(String boardCode, int startNum, int endNum) throws Exception {
		return null; // 페이징처리
	}

	@Override
	public List<BoardVo> searchAll(SearchCommand searchCmd, int startNum, int endNum) throws Exception {
		return null; //검색후 검색된 결과 페이징
	}

	@Override
	public BoardVo readBoard(int num) throws Exception {
		return null;
	}

	@Override
	public List<BoardImageVo> readmage(int boardNum) throws Exception {
		return null;
	}

	@Override
	public List<BoardRefVo> readRef(int boardNum) throws Exception {
		return null;
	}

	@Override
	public void updateHeart(int num) throws Exception {

	}

	@Override
	public void insertRef(BoardRefVo refVo) throws Exception {
		refDao.insert(refVo);
	}

	@Override
	public void updateRef(BoardRefVo refVo) throws Exception {
		refDao.update(refVo);
	}

	@Override
	public void deleteRef(int num) throws Exception {
		refDao.delete(num);
	}

	@Override
	public List<BoardVo> searchNickname(String nickname) throws Exception {
		return null;
	}

}
