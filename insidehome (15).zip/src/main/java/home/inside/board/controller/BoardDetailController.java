package home.inside.board.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import home.inside.board.service.IBoardDetailService;
import home.inside.board.service.IBoardPostService;
import home.inside.board.vo.SearchCommand;

@Controller
public class BoardDetailController {
	
	@Autowired
	private IBoardDetailService boardDetailService;
	@Autowired
	private IBoardPostService boardPostService;
	
	//게시글 목록, 검색 페이지
	public String selectAll(SearchCommand searchCmd, Model model) throws Exception{
		return null;
	}
	
	//게시글 상세조회 페이지
	public String readBoard(int num, Model model) throws Exception{
		return null;
	}
	
	//게시글 주천 요청
	public String updateHeart(int num) throws Exception{
		return null;
	}
	
	

}
